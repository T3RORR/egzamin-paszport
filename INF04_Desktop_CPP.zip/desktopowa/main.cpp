﻿#include <windows.h>
#using <System.dll>
#using <System.Drawing.dll>
#using <System.Windows.Forms.dll>

using namespace System;
using namespace System::Drawing;
using namespace System::IO;
using namespace System::Windows::Forms;

public ref class PassportForm : public Form {
private:
    TextBox^ numer;
    TextBox^ imie;
    TextBox^ nazwisko;
    RadioButton^ niebieskie;
    RadioButton^ zielone;
    RadioButton^ piwne;
    PictureBox^ zdjecie;
    PictureBox^ odcisk;

    Label^ MakeLabel(String^ text, int x, int y) {
        Label^ label = gcnew Label();
        label->Text = text;
        label->Location = Point(x, y);
        label->AutoSize = true;
        return label;
    }
    TextBox^ MakeTextBox(int x, int y) {
        TextBox^ field = gcnew TextBox();
        field->Location = Point(x, y);
        field->Size = Drawing::Size(180, 25);
        field->BackColor = Color::Azure;
        return field;
    }
    void LoadPicture(PictureBox^ target, String^ fileName) {
        if (target->Image != nullptr) {
            Image^ oldImage = target->Image;
            target->Image = nullptr;
            delete oldImage;
        }
        String^ path = Path::Combine(Application::StartupPath, fileName);
        if (!File::Exists(path)) return;
        try {
            array<Byte>^ bytes = File::ReadAllBytes(path);
            MemoryStream^ stream = gcnew MemoryStream(bytes);
            Image^ loaded = Image::FromStream(stream);
            target->Image = gcnew Bitmap(loaded);
            delete loaded;
            delete stream;
        } catch (Exception^) {
            target->Image = nullptr;
        }
    }
    void Numer_Leave(Object^ sender, EventArgs^ e) {
        String^ value = numer->Text->Trim();
        LoadPicture(zdjecie, value + "-zdjecie.jpg");
        LoadPicture(odcisk, value + "-odcisk.jpg");
    }
    void OK_Click(Object^ sender, EventArgs^ e) {
        if (String::IsNullOrWhiteSpace(numer->Text) ||
            String::IsNullOrWhiteSpace(imie->Text) ||
            String::IsNullOrWhiteSpace(nazwisko->Text)) {
            MessageBox::Show("Wprowadź dane");
            return;
        }
        String^ kolor = niebieskie->Checked ? "niebieskie" :
                        zielone->Checked ? "zielone" : "piwne";
        MessageBox::Show(imie->Text->Trim() + " " + nazwisko->Text->Trim() +
                         " kolor oczu " + kolor);
    }
public:
    PassportForm() {
        Text = "Wprowadzenie danych do paszportu. Wykonał: 00000000000";
        ClientSize = Drawing::Size(680, 290);
        BackColor = Color::CadetBlue;
        StartPosition = FormStartPosition::CenterScreen;
        FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
        MaximizeBox = false;
        Font = gcnew Drawing::Font("Segoe UI", 10);

        Controls->Add(MakeLabel("Numer", 30, 28));
        Controls->Add(MakeLabel("Imię", 30, 66));
        Controls->Add(MakeLabel("Nazwisko", 30, 104));
        numer = MakeTextBox(125, 24);
        imie = MakeTextBox(125, 62);
        nazwisko = MakeTextBox(125, 100);
        Controls->Add(numer);
        Controls->Add(imie);
        Controls->Add(nazwisko);
        numer->Leave += gcnew EventHandler(this, &PassportForm::Numer_Leave);

        GroupBox^ grupa = gcnew GroupBox();
        grupa->Text = "Kolor oczu";
        grupa->Location = Point(25, 151);
        grupa->Size = Drawing::Size(285, 118);
        niebieskie = gcnew RadioButton();
        niebieskie->Text = "niebieskie";
        niebieskie->Location = Point(18, 25);
        niebieskie->Checked = true;
        zielone = gcnew RadioButton();
        zielone->Text = "zielone";
        zielone->Location = Point(18, 54);
        piwne = gcnew RadioButton();
        piwne->Text = "piwne";
        piwne->Location = Point(18, 83);
        grupa->Controls->Add(niebieskie);
        grupa->Controls->Add(zielone);
        grupa->Controls->Add(piwne);
        Controls->Add(grupa);

        zdjecie = gcnew PictureBox();
        zdjecie->Location = Point(340, 24);
        zdjecie->Size = Drawing::Size(140, 180);
        zdjecie->SizeMode = PictureBoxSizeMode::Zoom;
        odcisk = gcnew PictureBox();
        odcisk->Location = Point(510, 24);
        odcisk->Size = Drawing::Size(140, 180);
        odcisk->SizeMode = PictureBoxSizeMode::Zoom;
        Controls->Add(zdjecie);
        Controls->Add(odcisk);

        Button^ ok = gcnew Button();
        ok->Text = "OK";
        ok->Location = Point(390, 224);
        ok->Size = Drawing::Size(210, 35);
        ok->BackColor = Color::Azure;
        ok->UseVisualStyleBackColor = false;
        ok->Click += gcnew EventHandler(this, &PassportForm::OK_Click);
        Controls->Add(ok);
        LoadPicture(zdjecie, "000-zdjecie.jpg");
        LoadPicture(odcisk, "000-odcisk.jpg");
    }
};

[STAThreadAttribute]
int main(array<String^>^) {
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);
    Application::Run(gcnew PassportForm());
    return 0;
}
