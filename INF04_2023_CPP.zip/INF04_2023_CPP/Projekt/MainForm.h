#pragma once
using namespace System;
using namespace System::Drawing;
using namespace System::Windows::Forms;

namespace INF042023 {
public ref class MainForm : public Form {
private:
    GroupBox^ employeeGroup;
    GroupBox^ passwordGroup;
    TextBox^ firstName;
    TextBox^ lastName;
    TextBox^ lengthBox;
    ComboBox^ positionBox;
    CheckBox^ lettersBox;
    CheckBox^ digitsBox;
    CheckBox^ specialBox;
    Button^ generateButton;
    Button^ approveButton;
    String^ generatedPassword;
    Random^ random;

    Label^ AddLabel(String^ title, int x, int y, Control^ parent) {
        Label^ label = gcnew Label();
        label->Text = title;
        label->Location = Point(x, y);
        label->AutoSize = true;
        parent->Controls->Add(label);
        return label;
    }

    TextBox^ AddTextBox(int x, int y, int width, Control^ parent) {
        TextBox^ field = gcnew TextBox();
        field->Location = Point(x, y);
        field->Size = Drawing::Size(width, 24);
        parent->Controls->Add(field);
        return field;
    }

    Button^ AddButton(String^ title, int x, int y, int width, Control^ parent) {
        Button^ button = gcnew Button();
        button->Text = title;
        button->Location = Point(x, y);
        button->Size = Drawing::Size(width, 32);
        button->BackColor = Color::SteelBlue;
        button->ForeColor = Color::White;
        button->FlatStyle = FlatStyle::Flat;
        parent->Controls->Add(button);
        return button;
    }

    void GeneratePassword(Object^ sender, EventArgs^ e) {
        int count;
        if (!Int32::TryParse(lengthBox->Text, count) || count < 1 || count > 10000) {
            MessageBox::Show("Podaj poprawna liczbe znakow (1-10000).", "Blad", MessageBoxButtons::OK, MessageBoxIcon::Warning);
            return;
        }
        String^ lowercase = "abcdefghijklmnopqrstuvwxyz";
        String^ uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String^ digits = "0123456789";
        String^ special = "!@#$%^&*()_+-=";
        int required = (lettersBox->Checked ? 1 : 0) + (digitsBox->Checked ? 1 : 0) + (specialBox->Checked ? 1 : 0);
        if (count < required) {
            MessageBox::Show("Zwieksz liczbe znakow, aby uwzglednic wybrane rodzaje znakow.", "Blad", MessageBoxButtons::OK, MessageBoxIcon::Warning);
            return;
        }
        array<wchar_t>^ result = gcnew array<wchar_t>(count);
        for (int i = 0; i < count; i++) result[i] = lowercase[random->Next(lowercase->Length)];
        int index = 0;
        if (lettersBox->Checked) result[index++] = uppercase[random->Next(uppercase->Length)];
        if (digitsBox->Checked) result[index++] = digits[random->Next(digits->Length)];
        if (specialBox->Checked) result[index++] = special[random->Next(special->Length)];
        for (int i = count - 1; i > 0; i--) {
            int j = random->Next(i + 1);
            wchar_t temp = result[i];
            result[i] = result[j];
            result[j] = temp;
        }
        generatedPassword = gcnew String(result);
        MessageBox::Show(generatedPassword, "Wygenerowane haslo", MessageBoxButtons::OK, MessageBoxIcon::Information);
    }

    void Approve(Object^ sender, EventArgs^ e) {
        String^ message = "Dane pracownika: " + firstName->Text + " " + lastName->Text + " " + positionBox->Text + " Haslo: " + generatedPassword;
        MessageBox::Show(message, "Dane pracownika", MessageBoxButtons::OK, MessageBoxIcon::Information);
    }

public:
    MainForm() {
        generatedPassword = "";
        random = gcnew Random();
        Text = "Dodaj pracownika - 00000000000";
        ClientSize = Drawing::Size(720, 360);
        BackColor = Color::LightSteelBlue;
        Font = gcnew Drawing::Font("Segoe UI", 10);
        StartPosition = FormStartPosition::CenterScreen;
        FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
        MaximizeBox = false;

        employeeGroup = gcnew GroupBox();
        employeeGroup->Text = "Dane pracownika";
        employeeGroup->Location = Point(35, 35);
        employeeGroup->Size = Drawing::Size(310, 245);
        Controls->Add(employeeGroup);

        AddLabel("Imie", 20, 45, employeeGroup);
        firstName = AddTextBox(125, 40, 155, employeeGroup);
        AddLabel("Nazwisko", 20, 95, employeeGroup);
        lastName = AddTextBox(125, 90, 155, employeeGroup);
        AddLabel("Stanowisko", 20, 145, employeeGroup);
        positionBox = gcnew ComboBox();
        positionBox->Location = Point(125, 140);
        positionBox->Size = Drawing::Size(155, 28);
        positionBox->DropDownStyle = ComboBoxStyle::DropDownList;
        positionBox->Items->AddRange(gcnew array<Object^>{"Kierownik", "Starszy programista", "Mlodszy programista", "Tester"});
        employeeGroup->Controls->Add(positionBox);

        passwordGroup = gcnew GroupBox();
        passwordGroup->Text = "Generowanie hasla";
        passwordGroup->Location = Point(375, 35);
        passwordGroup->Size = Drawing::Size(310, 245);
        Controls->Add(passwordGroup);
        AddLabel("Ile znakow?", 20, 38, passwordGroup);
        lengthBox = AddTextBox(160, 34, 125, passwordGroup);
        lettersBox = gcnew CheckBox();
        lettersBox->Text = "Male i wielkie litery";
        lettersBox->Location = Point(35, 77);
        lettersBox->AutoSize = true;
        lettersBox->Checked = true;
        passwordGroup->Controls->Add(lettersBox);
        digitsBox = gcnew CheckBox();
        digitsBox->Text = "Cyfry";
        digitsBox->Location = Point(35, 110);
        digitsBox->AutoSize = true;
        passwordGroup->Controls->Add(digitsBox);
        specialBox = gcnew CheckBox();
        specialBox->Text = "Znaki specjalne";
        specialBox->Location = Point(35, 143);
        specialBox->AutoSize = true;
        passwordGroup->Controls->Add(specialBox);
        generateButton = AddButton("Generuj haslo", 95, 190, 125, passwordGroup);
        generateButton->Click += gcnew EventHandler(this, &MainForm::GeneratePassword);
        approveButton = AddButton("Zatwierdz", 245, 300, 230, this);
        approveButton->Click += gcnew EventHandler(this, &MainForm::Approve);
    }
};
}
