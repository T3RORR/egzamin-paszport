INF.04 styczen 2023 - aplikacja desktopowa C++/CLI Windows Forms

Otworz Projekt/INF04_2023.vcxproj w Visual Studio 2022.
Zainstaluj komponent C++/CLI support for v143 build tools oraz .NET Framework development tools.
Wybierz Debug x64 i uruchom przez Ctrl+F5.
W MainForm.h zamien 00000000000 na swoj numer zdajacego.
Kod C++ nie zawiera komentarzy.
Projekt nie byl kompilowany na Windows w tym srodowisku.
