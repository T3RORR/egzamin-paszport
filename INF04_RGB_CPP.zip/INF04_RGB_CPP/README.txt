INF.04 czerwiec 2025 - aplikacja desktopowa RGB

1. Visual Studio 2022: zainstaluj Desktop development with C++ i C++/CLI support for v143 build tools.
2. Otworz RGBExam.vcxproj.
3. Wybierz Debug | x64 i uruchom Ctrl+F5.
4. Zmien w MainForm.h 00000000000 na swoj numer zdajacego.

Nie skompilowano ani nie przetestowano w srodowisku Windows.
