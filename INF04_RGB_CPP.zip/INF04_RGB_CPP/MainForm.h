﻿#pragma once
namespace RGBExam {
using namespace System;
using namespace System::Drawing;
using namespace System::Windows::Forms;
public ref class MainForm : public Form {
private:
    Panel^ preview;
    Label^ saved;
    array<TrackBar^>^ sliders;
    array<Label^>^ values;
    Button^ pick;
    void updatePreview(Object^ sender, EventArgs^ e) {
        for (int i = 0; i < 3; ++i) values[i]->Text = sliders[i]->Value.ToString();
        preview->BackColor = Color::FromArgb(sliders[0]->Value, sliders[1]->Value, sliders[2]->Value);
    }
    void saveColor(Object^ sender, EventArgs^ e) {
        Color c = preview->BackColor;
        saved->BackColor = c;
        saved->Text = String::Format("{0}, {1}, {2}", c.R, c.G, c.B);
        saved->ForeColor = (c.R * 299 + c.G * 587 + c.B * 114 < 128000) ? Color::White : Color::Black;
    }
public:
    MainForm() {
        Text = L"Wzornik kolorów RGB. Wykonał: 00000000000";
        ClientSize = Drawing::Size(760, 430);
        BackColor = Color::Cornsilk;
        StartPosition = FormStartPosition::CenterScreen;
        FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
        MaximizeBox = false;
        Font = gcnew Drawing::Font(L"Segoe UI", 10);

        preview = gcnew Panel();
        preview->Location = Point(38, 24);
        preview->Size = Drawing::Size(684, 100);
        preview->BackColor = Color::White;
        Controls->Add(preview);

        Label^ instruction = gcnew Label();
        instruction->Text = L"Dobierz kolor suwakami i zapisz przyciskiem:";
        instruction->Location = Point(38, 148);
        instruction->AutoSize = true;
        Controls->Add(instruction);

        sliders = gcnew array<TrackBar^>(3);
        values = gcnew array<Label^>(3);
        array<String^>^ names = gcnew array<String^>{L"R", L"G", L"B"};
        for (int i = 0; i < 3; ++i) {
            int y = 180 + i * 49;
            Label^ channel = gcnew Label();
            channel->Text = names[i];
            channel->Location = Point(40, y + 7);
            channel->Size = Drawing::Size(24, 25);
            Controls->Add(channel);
            TrackBar^ slider = gcnew TrackBar();
            slider->Minimum = 0;
            slider->Maximum = 255;
            slider->Value = 255;
            slider->TickStyle = TickStyle::None;
            slider->Location = Point(75, y);
            slider->Size = Drawing::Size(590, 40);
            slider->ValueChanged += gcnew EventHandler(this, &MainForm::updatePreview);
            Controls->Add(slider);
            sliders[i] = slider;
            Label^ value = gcnew Label();
            value->Text = L"255";
            value->Location = Point(680, y + 7);
            value->Size = Drawing::Size(44, 25);
            Controls->Add(value);
            values[i] = value;
        }
        pick = gcnew Button();
        pick->Text = L"Pobierz";
        pick->BackColor = Color::Peru;
        pick->UseVisualStyleBackColor = false;
        pick->FlatStyle = FlatStyle::Flat;
        pick->FlatAppearance->BorderSize = 0;
        pick->Location = Point(285, 330);
        pick->Size = Drawing::Size(190, 34);
        pick->Click += gcnew EventHandler(this, &MainForm::saveColor);
        Controls->Add(pick);
        saved = gcnew Label();
        saved->Text = L"255, 255, 255";
        saved->TextAlign = ContentAlignment::MiddleLeft;
        saved->BackColor = Color::White;
        saved->Location = Point(285, 375);
        saved->Size = Drawing::Size(190, 30);
        Controls->Add(saved);
    }
};
}
